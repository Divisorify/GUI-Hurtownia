package com.example.demo12;

public class AppLauncher {
    public static void main(String[] args) throws Exception {
        Main.main(args);
    }
}
